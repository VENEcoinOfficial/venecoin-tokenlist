# 🇻🇪 VENE Token – Venezuela Nueva Libre y Eterna  

**Contract Address (Polygon PoS):**  
[`0x4B9b9394a98dC6264c7d1CBfAd3E5633C0E886D8`](https://polygonscan.com/token/0x4B9b9394a98dC6264c7d1CBfAd3E5633C0E886D8)  

**Symbol:** VENE  
**Decimals:** 18  
**Max Supply:** 1,000,000,000 VENE  

---

### 🔗 Official Links  
- 🌐 Website: [https://www.venecoin.xyz](https://www.venecoin.xyz)  
- 📢 Telegram: [https://t.me/VENECoinOfficial](https://t.me/VENECoinOfficial)  
- 🐦 Twitter: *(pending official)*  
- 📈 Dexscreener: [VENE/USDT](https://dexscreener.com/polygon/0x4b9b9394a98dc6264c7d1cbfad3e5633c0e886d8)  
- 💰 Direct Buy (Uniswap): [Buy VENE](https://app.uniswap.org/explore/tokens/polygon/0x4b9b9394a98dc6264c7d1cbfad3e5633c0e886d8)  
- 🔎 Listings: [FreshCoins](https://www.freshcoins.io/coins/venezuela-nueva-libre-y-eterna) | [Coinscope](https://www.coinscope.co/coin/vene) | [CoinMooner](https://coinmooner.com/coins/venezuela-nueva-libre-y-eterna-vene)  

---

### 📊 Tokenomics (Updated October 2025)  
- 🔒 **Treasury (Vault):** 51.56%  
- 📢 **Marketing & Community:** 24.70%  
- 💧 **Liquidity / Market Making:** 22.20%  
- 🪙 **Liquidity Lock:** Locked until **Nov 30, 2025** (via Team Finance)  

---

### 📝 Notes  
- Standard ERC-20 token deployed on **Polygon PoS**.  
- No extra transfer fees (only Polygon gas).  
- No max wallet / blacklist / freeze functions.  
- Transparent structure for long-term growth.  

---

⚡ This repository hosts the official **VENE Tokenlist JSON** used for integrations.  
